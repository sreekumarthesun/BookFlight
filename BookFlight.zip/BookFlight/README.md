# MercuryTour Travel agency
## This project is intended for performing an automated functional test of Flight Reservations on [Mercury Tours](http://newtours.demoaut.com) 
Key Features :
- Selenium WebDriver and Java Bindings
- Page Object Model
logs
testng
maven and git hub
testing framework
